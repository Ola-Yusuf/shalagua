/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gb;

/**
 *
 * @author MADEY
 */
import java.awt.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.StringTokenizer;


class GB extends Frame implements Runnable
{
	Socket soc;	
	TextField tf;
	TextArea ta;
	Button btnSend,btnClose;
	String sendTo;
        List ls;
	String LoginName;
	Thread t=null;
	DataOutputStream dout;
	DataInputStream din;
	GB(String LoginName,String chatwith, String ServerIp) throws Exception
	{
		super(LoginName);
		this.LoginName=LoginName;
		sendTo=chatwith;
		tf=new TextField(50);
		ta=new TextArea(50,50);
                ls =  new List();
		btnSend=new Button("Send");
		btnClose=new Button("Close");
		soc=new Socket(ServerIp,5217);

		din=new DataInputStream(soc.getInputStream()); 
		dout=new DataOutputStream(soc.getOutputStream());		
		dout.writeUTF(LoginName);

		t=new Thread(this);
		t.start();

	}
	void setup()
	{
		setSize(600,400);
		setLayout(new GridLayout(2,1));

		add(ta);
		Panel p=new Panel();
		p.add(ls);
		p.add(tf);
		p.add(btnSend);
		p.add(btnClose);
		add(p);
		show();		
	}
    @Override
	public boolean action(Event e,Object o)
	{
		if(e.arg.equals("Send"))
		{
			try
			{
				dout.writeUTF("DATA" + " "+sendTo + " "+LoginName+" " + tf.getText().toString());			
				ta.append("\n" + LoginName + " Says:" + tf.getText().toString());	
				tf.setText("");
			}
			catch(Exception ex)
			{
			}	
		}
		else if(e.arg.equals("Close"))
		{
			try
			{
				dout.writeUTF("LOGOUT "+LoginName );
				System.exit(1);
			}
			catch(Exception ex)
			{
			}
			
		}
		
		return super.action(e,o);
	}
	public static void main(String args[]) throws Exception
	{
		GB Client1=new GB("Matthew","Olu","127.0.0.1");
		Client1.setup();				
	}	
    @Override
	public void run()
	{		
		while(true)
		{
			try
			{
                            String s = din.readUTF();
                            StringTokenizer st = new StringTokenizer(s);
                            String test = st.nextToken();
                            String sent = st.nextToken();
                           // String sender = st.nextToken()
                            
                            if(test.equals("LOGIN"))
                            {
                                ls.add(sent);
                            }
                            else if(test.equals("LOGOUT"))
                            {
                                ls.remove(sent);
                            }
                            else //if(test.equals("DATA"))
                            {
                               // ta.append( "\n" + sendTo + " Says :" + s);
                                String sender = st.nextToken();
                                String msg = "";while(st.hasMoreTokens())
                                {
                                    msg= msg+" "+st.nextToken();
                                }
                                ta.append("\n"+sender+" Says :"+msg);
                            }	
			}
			catch(Exception ex)
			{
			}
		}
	}
}