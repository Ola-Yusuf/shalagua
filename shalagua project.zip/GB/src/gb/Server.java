/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gb;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.StringTokenizer;

class chatServer
{
	private static ArrayList ClientSockets;
	private static ArrayList LoginNames;
	
	chatServer() throws Exception
	{
		ServerSocket soc=new ServerSocket(5217);
		ClientSockets = new ArrayList();
		LoginNames = new ArrayList();

		while(true)
		{	
			Socket CSoc=soc.accept();		
			AcceptClient obClient=new AcceptClient(CSoc);
                        
		}
	}
	public static void main(String args[]) throws Exception
	{
		
		chatServer ob=new chatServer();
	}

class AcceptClient extends Thread
{
	Socket ClientSocket;
	DataInputStream din;
	DataOutputStream dout;
        String Logname;
	AcceptClient (Socket CSoc) throws Exception
	{
		ClientSocket=CSoc;

		din=new DataInputStream(ClientSocket.getInputStream());
		dout=new DataOutputStream(ClientSocket.getOutputStream());
		
		String LoginName=din.readUTF();
		System.out.println("User Logged In :" + LoginName);
                Logname = "LOGIN "+LoginName;
		LoginNames.add(LoginName);
                ClientSockets.add(ClientSocket);
                //String sendname = din.readUTF();
                for(int i=0; i<LoginNames.size()-1;i++)
                {
                    dout.writeUTF("LOGIN "+LoginNames.get(i));
                }
                for(int i =0; i<ClientSockets.size()-1;i++)
                {
                    DataInputStream di = null;
                    DataOutputStream dot = null;
                    try{Socket sk = (Socket)ClientSockets.get(i);
                    di = new DataInputStream(sk.getInputStream());
                    dot = new DataOutputStream(sk.getOutputStream());
                    dot.writeUTF(Logname);}
                    finally{ }
                }
                
		//Broadcast broadcast = new Broadcast(Logname, ClientSockets, LoginNames);
                //dout.writeUTF(Logname);
		start();
	}
        @Override
	public void run()
	{
		while(true)
		{
			
			try
			{
				String msgFromClient=new String();
				msgFromClient=din.readUTF();
				StringTokenizer st=new StringTokenizer(msgFromClient);
                                String MsgType=st.nextToken();
				String Sendto=st.nextToken();
                                //String Sender = 
				
				int iCount=0;
	
				if(MsgType.equals("LOGOUT"))
				{
					for(iCount=0;iCount<LoginNames.size();iCount++)
					{
						if(LoginNames.get(iCount).equals(Sendto))
						{
                                                    
							LoginNames.remove(iCount);
							ClientSockets.remove(iCount);
                                                       iCount-=1;
							System.out.println("User " + Sendto +" Logged Out ...");
                                                        continue;
							//break;
						}
                                                DataOutputStream dot;
                                                try
                                                {
                                                     Socket sk = (Socket)ClientSockets.get(iCount);
                                                     dot = new DataOutputStream(sk.getOutputStream());
                                                     dot.writeUTF("LOGOUT"+" "+Sendto);
                                                }
                                                finally{ }
					}
	
				}
                                
                                else
				{
                                        String sender = st.nextToken();
					String msg="";
					while(st.hasMoreTokens())
					{
						msg=msg+" " +st.nextToken();
					}
                                        
					for(iCount=0;iCount<LoginNames.size();iCount++)
					{
						if(LoginNames.get(iCount).equals(Sendto))
						{	
							Socket tSoc=(Socket)ClientSockets.get(iCount);							
							DataOutputStream tdout=new DataOutputStream(tSoc.getOutputStream());
							//tdout.writeUTF(msg);
                                                        tdout.writeUTF(msgFromClient);
							break;
						}
					}
					if(iCount==LoginNames.size())
					{
						dout.writeUTF("I am offline");
					}
					else
					{
						
					}
				}
                                
				if(MsgType.equals("LOGOUT"))
				{
					break;
				}

			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
		
		}		
	}    
}
}
